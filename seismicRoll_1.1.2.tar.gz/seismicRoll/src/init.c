#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* .Call calls */
extern SEXP seismicRoll_roll_hampel_numeric_vector(SEXP, SEXP, SEXP);
extern SEXP seismicRoll_roll_mean_numeric_vector(SEXP, SEXP, SEXP, SEXP);
extern SEXP seismicRoll_roll_median_numeric_vector(SEXP, SEXP, SEXP);
extern SEXP seismicRoll_roll_sd_numeric_vector(SEXP, SEXP, SEXP, SEXP);
extern SEXP seismicRoll_roll_stalta_numeric_vector(SEXP, SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"seismicRoll_roll_hampel_numeric_vector", (DL_FUNC) &seismicRoll_roll_hampel_numeric_vector, 3},
    {"seismicRoll_roll_mean_numeric_vector",   (DL_FUNC) &seismicRoll_roll_mean_numeric_vector,   4},
    {"seismicRoll_roll_median_numeric_vector", (DL_FUNC) &seismicRoll_roll_median_numeric_vector, 3},
    {"seismicRoll_roll_sd_numeric_vector",     (DL_FUNC) &seismicRoll_roll_sd_numeric_vector,     4},
    {"seismicRoll_roll_stalta_numeric_vector", (DL_FUNC) &seismicRoll_roll_stalta_numeric_vector, 4},
    {NULL, NULL, 0}
};

void R_init_seismicRoll(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}

